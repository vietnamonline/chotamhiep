@extends('layouts.app')

@section('content')

    <div class="col-lg-6 col-lg-offset-3">
        <div class="panel">
            <!--Horizontal Form-->

            <form class="form-horizontal" action="{{ route('refund_request_time_config') }}" method="POST" enctype="multipart/form-data">
            	@csrf
                <div class="panel-body">
                    <div class="form-group">
                        <input type="hidden" name="type" value="refund_request_time">
                        <label class="col-lg-5 control-label">{{__('Set Time for sending Refund Request')}}</label>
                        <div class="col-lg-5">
                            <input type="number" min="0" step="1" value="{{ \App\BusinessSetting::where('type', 'refund_request_time')->first()->value }}" placeholder="" name="value" class="form-control">
                        </div>
                        <div class="col-lg-2">
                            <option class="form-control">days</option>
                        </div>
                    </div>
                </div>
                <div class="panel-footer text-right">
                    <button class="btn btn-purple" type="submit">{{__('Save')}}</button>
                </div>
            </form>
            <!--===================================================-->
            <!--End Horizontal Form-->

        </div>
    </div>


@endsection
